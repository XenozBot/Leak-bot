const { MessageEmbed } = require('discord.js');
const { readdirSync } = require('fs');
module.exports = {
    name: 'help',
    aliases: ["h"],
    go: async (client, db, message, args, prefix, color) => {
        if (db.get(`owner_${client.user.id}_${message.author.id}`) === true) {
            const embed = new MessageEmbed()
                .setTitle(`Liste des commandes`)
                .setColor(color)
                .addFields(
                    { name: `\`${prefix}antiraid <on/max/off>\``, value: "**Active ou désactive l'anti raid**"},
                    { name: `\`${prefix}antiraid config\``, value: "**Modifie l'activité et les sanctions de l'anti raid**"},
                    { name: `\`${prefix}whitelist <add/remove>\``, value: "**Ajoute ou retire un utilisateur de la whitelist**"},
                    { name: `\`${prefix}whitelist clear\``, value: "**Retire tous les utilisateurs de la whitelist**"},
                    { name: `\`${prefix}whitelist list\``, value: "**Affiche la liste de tous les utilisateurs whitelist**"},
                    { name: `\`${prefix}owner <add/remove>\``, value: "**Ajoute ou retire un utilisateur de la liste des owners**"},
                    { name: `\`${prefix}owner clear\``, value: "**Retire tous les utilisateurs de la liste des owners**"},
                    { name: `\`${prefix}owner list\``, value: "**Affiche la liste de tous les owners du bot**"},
                    { name: `\`${prefix}blacklist <add/remove>\``, value: "**Blacklist ou unblacklist un utilisateur**"},
                    { name: `\`${prefix}blacklist clear\``, value: "**Retire tous les utilisateurs de la blacklist**"},
                    { name: `\`${prefix}blacklist list\``, value: "**Affiche la liste des utilisateurs blacklist**"},
                );
            message.reply({ embeds: [embed], allowedMentions: { repliedUser: false } });
        }
    }
}
